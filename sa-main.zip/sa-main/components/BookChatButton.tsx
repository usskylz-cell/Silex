"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MessageCircle } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { createConversation } from "@/lib/chat";

export function BookChatButton({
  merchantId,
  message,
  productId,
  label = "حجز بالدردشة",
  className = "",
}: {
  merchantId: string;
  message?: string;
  productId?: string;
  label?: string;
  className?: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function go() {
    if (busy) return;
    setBusy(true);
    try {
      const { data } = await supabase.auth.getSession();
      const uid = data.session?.user.id;
      if (!uid) return router.push("/login");
      if (uid === merchantId) return;
      const convId = await createConversation(uid, merchantId);
      const q = new URLSearchParams();
      if (message) q.set("draft", message.replace(/\n+/g, " — ").slice(0, 1000));
      if (productId) q.set("product", productId);
      const qs = q.toString();
      router.push(`/chat/${convId}${qs ? `?${qs}` : ""}`);
    } catch (e: any) {
      alert(e?.message || "تعذّر فتح الدردشة، حاول مجدداً");
    } finally {
      setBusy(false);
    }
  }

  return (
    <button onClick={go} disabled={busy} className={`${className} disabled:opacity-50`}>
      <MessageCircle size={15} />
      {busy ? "جارٍ الفتح..." : label}
    </button>
  );
}
