"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronRight, Plus, Check, Package, Play, AlertCircle } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useProfile } from "@/lib/useProfile";
import { getMerchantProducts, getCategories, type Product, type Category } from "@/lib/catalog";

type Step = "product" | "media" | "details" | "publishing" | "done";

const MAX_IMAGE = 10 * 1024 * 1024;
const MAX_VIDEO = 50 * 1024 * 1024;
const IMG_OK = ["image/jpeg", "image/png", "image/webp", "image/gif", "image/heic"];
const VID_OK = ["video/mp4", "video/quicktime", "video/webm"];

function explain(e: any): string {
  const m = String(e?.message || e || "").toLowerCase();
  if (!navigator.onLine || m.includes("failed to fetch") || m.includes("network"))
    return "فشل النشر بسبب ضعف أو انقطاع الإنترنت. تحقق من الاتصال وحاول مجدداً.";
  if (m.includes("payload") || m.includes("too large") || m.includes("size"))
    return "فشل النشر: حجم الملف كبير جداً.";
  if (m.includes("mime") || m.includes("type") || m.includes("not supported"))
    return "فشل النشر: نوع الملف غير مدعوم.";
  if (m.includes("row-level") || m.includes("policy") || m.includes("permission") || m.includes("jwt"))
    return "فشل النشر: لا تملك صلاحية النشر. سجّل الدخول مجدداً.";
  if (m.includes("bucket"))
    return "فشل النشر: مخزن الملفات غير مهيأ في الخادم.";
  return `فشل النشر: ${e?.message || "خطأ غير معروف"}`;
}

export default function StudioPage() {
  const router = useRouter();
  const { user, loading: authLoading } = useProfile();

  const [step, setStep] = useState<Step>("product");
  const [myProducts, setMyProducts] = useState<Product[] | null>(null);
  const [cats, setCats] = useState<Category[]>([]);
  const [product, setProduct] = useState<Product | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isVideo, setIsVideo] = useState(false);
  const [category, setCategory] = useState("");
  const [caption, setCaption] = useState("");
  const [progress, setProgress] = useState(0);
  const [pickErr, setPickErr] = useState("");
  const [err, setErr] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    getMerchantProducts(user.id).then(setMyProducts);
    getCategories().then(setCats);
  }, [user]);

  if (authLoading) return null;
  if (!user) {
    router.replace("/login");
    return null;
  }

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    const video = f.type.startsWith("video");
    const okType = video ? VID_OK.includes(f.type) : IMG_OK.includes(f.type);
    if (!okType) {
      setPickErr("هذا النوع من الملفات غير مدعوم. اختر صورة (JPG/PNG/WEBP) أو فيديو (MP4/MOV).");
      return;
    }
    if (f.size > (video ? MAX_VIDEO : MAX_IMAGE)) {
      setPickErr(video ? "الفيديو أكبر من 50 ميغابايت." : "الصورة أكبر من 10 ميغابايت.");
      return;
    }
    setPickErr("");
    setFile(f);
    setIsVideo(video);
    setPreview(URL.createObjectURL(f));
    setStep("details");
  }

  function goBack() {
    if (step === "media") setStep("product");
    else if (step === "details") setStep("media");
    else router.back();
  }

  async function publish() {
    if (!product || !file) return;
    if (!category) return setErr("اختر التصنيف");
    setStep("publishing");
    setErr("");
    setProgress(8);
    const tick = setInterval(() => setProgress((p) => (p < 85 ? p + 4 : p)), 400);
    try {
      const ext = (file.name.split(".").pop() || "bin").toLowerCase();
      const path = `${user!.id}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("posts").upload(path, file, { contentType: file.type });
      if (upErr) throw upErr;
      const { data } = supabase.storage.from("posts").getPublicUrl(path);
      setProgress(92);

      const tags = Array.from(new Set(caption.match(/#[^\s#]+/g)?.map((t) => t.slice(1)) ?? []));
      const { error: dbErr } = await supabase.from("posts").insert({
        user_id: user!.id,
        product_id: product.id,
        category: category || null,
        title: null,
        caption: caption.trim() || null,
        hashtags: tags.length ? tags : null,
        image_url: data.publicUrl,
        media_type: isVideo ? "video" : "image",
      });
      if (dbErr) throw dbErr;

      clearInterval(tick);
      setProgress(100);
      setStep("done");
      setTimeout(() => router.push("/profile"), 1000);
    } catch (e: any) {
      clearInterval(tick);
      setErr(explain(e));
      setStep("details");
    }
  }

  const titles: Record<Step, string> = {
    product: "اختر المنتج",
    media: "أضف محتوى",
    details: "نشر",
    publishing: "جارٍ النشر...",
    done: "تم النشر",
  };

  return (
    <div className="min-h-screen bg-paper flex flex-col">
      <div className="flex items-center gap-3 px-6 pt-6 pb-3">
        {step !== "publishing" && step !== "done" && (
          <button onClick={goBack} aria-label="رجوع" className="w-9 h-9 rounded-full bg-chip flex items-center justify-center">
            <ChevronRight size={18} />
          </button>
        )}
        <h1 className="font-display text-[18px] flex-1">{titles[step]}</h1>
        {(step === "product" || step === "media" || step === "details") && (
          <span className="text-xs text-muted">{step === "product" ? 1 : step === "media" ? 2 : 3}/3</span>
        )}
      </div>

      {step === "product" && (
        <div className="px-6 mt-4 max-w-sm mx-auto w-full flex flex-col gap-2">
          {myProducts === null && <p className="text-sm text-muted text-center py-6">جارٍ التحميل...</p>}

          {myProducts !== null && myProducts.length === 0 && (
            <div className="flex flex-col items-center text-center gap-3 py-8">
              <div className="w-14 h-14 rounded-full bg-chip flex items-center justify-center">
                <Package size={24} className="text-ink/50" />
              </div>
              <p className="text-sm text-ink/80">أضف منتجاً واحداً على الأقل قبل النشر.</p>
              <button
                onClick={() => router.push("/profile/studio/product")}
                className="w-full bg-ink text-white rounded-pill py-3.5 text-sm font-semibold mt-2"
              >
                أضف منتجاً
              </button>
            </div>
          )}

          {myProducts?.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                setProduct(p);
                setCategory(p.category || "");
                setStep("media");
              }}
              className="flex items-center gap-3 bg-card shadow-soft rounded-2xl p-3 text-right"
            >
              <img src={p.image} alt="" className="w-14 h-14 rounded-xl object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{p.name}</p>
                <p className="text-xs text-muted mt-0.5">${p.price}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {step === "media" && (
        <div className="px-6 mt-6 max-w-sm mx-auto w-full flex flex-col items-center gap-4">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            aria-label="إضافة"
            className="w-full aspect-square rounded-3xl bg-chip flex items-center justify-center hover:bg-line/40 transition-colors"
          >
            <span className="w-20 h-20 rounded-full bg-ink text-white flex items-center justify-center">
              <Plus size={38} strokeWidth={2.2} />
            </span>
          </button>
          <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleFile} />
          {pickErr && (
            <p className="flex items-start gap-2 text-xs text-red-600 bg-red-500/10 border border-red-500/20 rounded-xl p-3 w-full">
              <AlertCircle size={14} className="shrink-0 mt-0.5" />
              {pickErr}
            </p>
          )}
        </div>
      )}

      {step === "details" && product && (
        <div className="px-6 mt-4 max-w-sm mx-auto w-full flex flex-col gap-4">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="relative aspect-square rounded-2xl bg-chip overflow-hidden flex items-center justify-center"
          >
            {preview &&
              (isVideo ? (
                <>
                  <video src={preview} muted playsInline className="absolute inset-0 w-full h-full object-cover" />
                  <span className="relative w-12 h-12 rounded-full bg-black/50 text-white flex items-center justify-center">
                    <Play size={20} />
                  </span>
                </>
              ) : (
                <img src={preview} alt="" className="absolute inset-0 w-full h-full object-cover" />
              ))}
          </button>
          <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleFile} />

          <div>
            <p className="text-[11px] text-muted mb-2 px-1">التصنيف</p>
            <div className="flex flex-wrap gap-2">
              {cats.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setCategory(c.id)}
                  className={`px-4 py-2 rounded-pill text-sm font-medium ${
                    category === c.id ? "bg-ink text-white" : "bg-chip text-ink/70"
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value.slice(0, 1000))}
            rows={3}
            placeholder="اكتب وصفاً (اختياري)"
            className="w-full bg-chip rounded-2xl p-4 text-sm outline-none resize-none focus:ring-1 focus:ring-ink/20"
          />

          {err && (
            <p className="flex items-start gap-2 text-xs text-red-600 bg-red-500/10 border border-red-500/20 rounded-xl p-3">
              <AlertCircle size={14} className="shrink-0 mt-0.5" />
              {err}
            </p>
          )}

          <button onClick={publish} className="w-full bg-ink text-white rounded-pill py-3.5 text-sm font-semibold">
            نشر
          </button>
        </div>
      )}

      {step === "publishing" && (
        <div className="flex-1 flex flex-col items-center justify-center gap-4 px-10">
          <div className="w-10 h-10 border-2 border-ink/20 border-t-ink rounded-full animate-spin" />
          <div className="w-full max-w-xs h-1.5 rounded-full bg-chip overflow-hidden">
            <div className="h-full bg-ink transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-sm text-muted">جارٍ رفع المنشور... {progress}%</p>
        </div>
      )}

      {step === "done" && (
        <div className="flex-1 flex flex-col items-center justify-center gap-3">
          <div className="w-14 h-14 rounded-full bg-green-500/10 flex items-center justify-center">
            <Check size={28} className="text-green-600" />
          </div>
          <p className="text-sm font-semibold">تم النشر بنجاح</p>
        </div>
      )}
    </div>
  );
}
